---
# Display name
title: Rundong Li

# Username (this should match the folder name and the name on publications)
authors:
- Rundong Li

# Is this the primary user of the site?
superuser: false

# Role/position (e.g., Professor of Artificial Intelligence)
role: Visitors

# Organizations/Affiliations
organizations:
- name: School of Automation Science and Electrical Engineering, Beihang University
  url: "http://asee.buaa.edu.cn/"

# Short bio (displayed in user profile at end of posts)
bio: Cross modal retrieval

# List each interest with a dash
interests:
- Cross modal retrieval
#  - Video-text grounding
education:
  courses:
    - course: Bachelor of Engineering
      institution: Beihang University (BUAA), CHINA
      year: 09/2018-06/2022

# Social/Academic Networking
# For available icons, see: https://sourcethemes.com/academic/docs/page-builder/#icons
#   For an email link, use "fas" icon pack, "envelope" icon, and a link in the
#   form "mailto:your-email@example.com" or "#contact" for contact widget.
social:
- icon: envelope
  icon_pack: fas
  link: "li10010@buaa.edu.cn"  # For a direct email link, use "mailto:1710241903@vip.henu.edu.cn".
# - icon: google-scholar
#   icon_pack: ai
#   link:
- icon: github
  icon_pack: fab
  link: https://github.com/li100102
# Link to a PDF of your resume/CV from the About widget.
# To enable, copy your resume/CV to `static/files/cv.pdf` and uncomment the lines below.
# - icon: cv
#   icon_pack: ai
#   link: files/cv.pdf

# Enter email to display Gravatar (if Gravatar enabled in Config)
email: ""

# Organizational groups that you belong to (for People widget)
#   Set this to `[]` or comment out if you are not using People widget.
user_groups:
- Visitor
---
He is a third year undergraduate student at School of Automation Science and Electrical Engineering (SASEE), Beihang University (BUAA). He is currently having an internship at Chinese Academy of Sciences (CAS) with the guidence of
<a href="http://dsd.future-lab.cn/members/qin.html" target="_blank">Prof. Jing Yu</a>.
His primary research interests is Multi-modal Machine Learning.
